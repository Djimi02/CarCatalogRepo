package com.example.CarCatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
